

import React, { useState } from 'react';
import GoogleIcon from './icons/GoogleIcon';
import FacebookIcon from './icons/FacebookIcon';
import { useTranslation } from '../contexts/LanguageContext';

interface AuthScreenProps {
  onLogin: (email: string, pass: string) => void;
  onSignUp: (name: string, username: string, email: string, pass: string) => void;
  onSocialLogin: (provider: 'google' | 'facebook') => void;
  onGuestLogin: () => void;
  onForgotPassword: () => void;
}

const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin, onSignUp, onSocialLogin, onGuestLogin, onForgotPassword }) => {
  const [isLogin, setIsLogin] = useState(true);
  
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { t } = useTranslation();

  const inputClasses = "w-full px-4 py-3 rounded-md bg-gray-100 dark:bg-neutral-800 border border-gray-200 dark:border-neutral-700 focus:outline-none focus:ring-2 focus:ring-orange-500 text-gray-800 dark:text-gray-200";
  const buttonClasses = "w-full py-3 rounded-md font-semibold text-white transition-colors";
  const socialButtonClasses = "w-full flex items-center justify-center py-3 rounded-md border border-gray-300 dark:border-neutral-700 hover:bg-gray-50 dark:hover:bg-neutral-800 transition-colors";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLogin) {
      onLogin(email, password);
    } else {
      if (!fullName || !username) {
        alert("Please fill in all fields.");
        return;
      }
      onSignUp(fullName, username, email, password);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-slate-50 dark:bg-neutral-950 p-4">
      <div className="w-full max-w-sm mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-orange-500">{t('appName')}</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-2">
            {isLogin ? t('welcomeBack') : t('joinCommunity')}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <>
              <input type="text" placeholder={t('fullName')} className={inputClasses} value={fullName} onChange={e => setFullName(e.target.value)} required />
              <input type="text" placeholder={t('username')} className={inputClasses} value={username} onChange={e => setUsername(e.target.value)} required />
            </>
          )}
          <input type="email" placeholder={t('emailAddress')} className={inputClasses} value={email} onChange={e => setEmail(e.target.value)} required />
          <input type="password" placeholder={t('password')} className={inputClasses} value={password} onChange={e => setPassword(e.target.value)} required />
          
          {isLogin && (
            <div className="text-end -mt-2">
                <button type="button" onClick={onForgotPassword} className="text-sm font-semibold text-orange-500 hover:text-orange-600">
                    {t('forgotPassword')}
                </button>
            </div>
          )}
          
          <button type="submit" className={`${buttonClasses} bg-orange-600 hover:bg-orange-700`}>
            {isLogin ? t('logIn') : t('createAccount')}
          </button>
        </form>

        <div className="relative my-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-300 dark:border-neutral-700" />
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-slate-50 dark:bg-neutral-950 text-gray-500 dark:text-gray-400">{t('or')}</span>
          </div>
        </div>

        <div className="space-y-3">
          <button onClick={() => onSocialLogin('google')} className={socialButtonClasses}>
            <GoogleIcon className="w-6 h-6 mx-3" />
            <span className="font-semibold text-gray-700 dark:text-gray-300">{t('continueWithGoogle')}</span>
          </button>
          <button onClick={() => onSocialLogin('facebook')} className={socialButtonClasses}>
            <FacebookIcon className="w-6 h-6 mx-3" />
            <span className="font-semibold text-gray-700 dark:text-gray-300">{t('continueWithFacebook')}</span>
          </button>
           <button onClick={onGuestLogin} className={`${socialButtonClasses} text-gray-700 dark:text-gray-300 font-semibold`}>
            {t('continueAsGuest')}
          </button>
        </div>

        <p className="mt-8 text-center text-sm text-gray-500 dark:text-gray-400">
          {isLogin ? t('dontHaveAccount') : t('alreadyHaveAccount')}
          <button onClick={() => setIsLogin(!isLogin)} className="font-semibold text-orange-500 hover:text-orange-600 ms-1">
            {isLogin ? t('signUp') : t('logIn')}
          </button>
        </p>
      </div>
    </div>
  );
};

export default AuthScreen;